import React from 'react'

const Error = () => {
  return (
    <>
      <h1>Error</h1>
    </>
  )
}

export default Error