import React from 'react'

const Offers = () => {
  return (
    <>
     <h1>Offers</h1> 
    </>
  )
}

export default Offers
