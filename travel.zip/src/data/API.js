export const API = [
    {
        image: "../images/place1.jpg",
        title : "Rome, Italty",
        price: "$5,42k",
        days : "10 Days Trip"
    },
    {
        image: "../images/place2.jpg",
        title : "Rome, Italty",
        price: "$5,42k",
        days : "10 Days Trip"
    },
    {
        image: "../images/place3.jpg",
        title : "Rome, Italty",
        price: "$5,42k",
        days : "10 Days Trip"
    },
    {
        image: "../images/place4.jpg",
        title : "Rome, Italty",
        price: "$5,42k",
        days : "10 Days Trip"
    },
    {
        image: "../images/place5.jpg",
        title : "Rome, Italty",
        price: "$5,42k",
        days : "10 Days Trip"
    },
]